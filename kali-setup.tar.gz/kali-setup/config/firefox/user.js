// Tema escuro no chrome do Firefox e nas paginas que suportam
user_pref("ui.systemUsesDarkTheme", 1);
user_pref("layout.css.prefers-color-scheme.content-override", 0);
user_pref("browser.theme.content-theme", 0);
user_pref("browser.theme.toolbar-theme", 0);
// Sem animacoes (VM)
user_pref("toolkit.cosmeticAnimations.enabled", false);
